module.exports = (req, res)=>{
	const availableTimeSlots = "";
	const selectedDate ="";
	
	res.render('g2Routes' , {availableTimeSlots,selectedDate});
};