module.exports = (req, res)=>{
	res.render('loginRoutes');
};