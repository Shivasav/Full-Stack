module.exports = (req, res)=>{
	let appointments = ""
	res.render('examiner' ,{appointments});
};