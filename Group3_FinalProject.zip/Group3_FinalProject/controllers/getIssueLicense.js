module.exports = (req, res)=>{
	let users = ""
	res.render('issueLicense' ,{users});
};