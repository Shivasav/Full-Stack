module.exports = (req, res) => {

	const availableTimeSlots = "";
	const selectedDate ="";

	res.render('appointment', { availableTimeSlots,selectedDate });
};