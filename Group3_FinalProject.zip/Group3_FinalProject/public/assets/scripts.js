/*!
* Start Bootstrap - Clean Blog v6.0.9 (https://startbootstrap.com/theme/clean-blog)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-clean-blog/blob/master/LICENSE)
*/
function validateLoginForm() {
    let username = document.getElementById("loginUsername").value;
    let password = document.getElementById("loginPassword").value;

    if (username === "") {
        alert("Username is required");
        return false; // Prevent form submission
    }
    if (password === "") {
        alert("Password is required");
        return false; // Prevent form submission
    }
    return true;
}
function validateSignupForm() {
    let username = document.getElementById("signupUsername").value;
    let password = document.getElementById("signupPassword").value;
    let repeatedPassword = document.getElementById("repeatPassword").value;

    if (username === "") {
        alert("Username is required");
        return false; // Prevent form submission
    }
    if (password === "") {
        alert("Password is required");
        return false; // Prevent form submission
    }

    if (repeatedPassword === "") {
        alert("Repeated password is required");
        return false; // Prevent form submission
    }

    if (password != repeatedPassword) {
        alert("Password don't match please check password");
        return false;
    }
    return true;
}
function validateG2Form() {
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var licenceNo = document.getElementById("licenceNo").value;
    var age = document.getElementById("age").value;
    var dob = document.getElementById("dob").value;


    var make = document.getElementById("make").value;
    var model = document.getElementById("model").value;
    var year = document.getElementById("year").value;
    var plateNo = document.getElementById("plateNo").value;





    // Check if First Name is empty
    if (firstName === "") {
        alert("First Name is required");
        return false; // Prevent form submission
    }

    // Check if Last Name is empty
    if (lastName === "") {
        alert("Last Name is required");
        return false; // Prevent form submission
    }

    // Check if licenceNo is empty
    if (licenceNo === "") {
        alert("licence Number is required");
        return false; // Prevent form submission
    }

    // Check if age is empty
    if (age === "") {
        alert("age is required");
        return false; // Prevent form submission
    }

    // Check if age is empty
    if (dob === "") {
        alert("dob is required");
        return false; // Prevent form submission
    }


    // Check if Make is empty
    if (make === "") {
        alert("Make is required");
        return false; // Prevent form submission
    }

    // Check if Model is empty
    if (model === "") {
        alert("Model is required");
        return false; // Prevent form submission
    }

    // Check if year is empty
    if (year === "") {
        alert("year is required");
        return false; // Prevent form submission
    }

    // Check if plateNo is empty
    if (plateNo === "") {
        alert("Plate Number is required");
        return false; // Prevent form submission
    }

    return true; // Allow form submission if all fields are valid
}

function validateGForm() {
    var make = document.getElementById("editMake").value;
    var model = document.getElementById("editModel").value;
    var year = document.getElementById("editYear").value;
    var plateNo = document.getElementById("editPlateNo").value;
    // Check if Make is empty
    if (make === "") {
        alert("Make is required");
        return false; // Prevent form submission
    }

    // Check if Model is empty
    if (model === "") {
        alert("Model is required");
        return false; // Prevent form submission
    }

    // Check if year is empty
    if (year === "") {
        alert("year is required");
        return false; // Prevent form submission
    }

    // Check if plateNo is empty
    if (plateNo === "") {
        alert("Plate Number is required");
        return false; // Prevent form submission
    }

    return true; // Allow form submission if all fields are valid
}




window.addEventListener('DOMContentLoaded', () => {
    let scrollPos = 0;
    const mainNav = document.getElementById('mainNav');
    const headerHeight = mainNav.clientHeight;
    window.addEventListener('scroll', function () {
        const currentTop = document.body.getBoundingClientRect().top * -1;
        if (currentTop < scrollPos) {
            // Scrolling Up
            if (currentTop > 0 && mainNav.classList.contains('is-fixed')) {
                mainNav.classList.add('is-visible');
            } else {
                console.log(123);
                mainNav.classList.remove('is-visible', 'is-fixed');
            }
        } else {
            // Scrolling Down
            mainNav.classList.remove(['is-visible']);
            if (currentTop > headerHeight && !mainNav.classList.contains('is-fixed')) {
                mainNav.classList.add('is-fixed');
            }
        }
        scrollPos = currentTop;
    });
    // Attach change event to the date input
    
    $("#dateg2").change(function () {
        var selectedDate = $(this).val();

        // Make a POST request to get available time slots
        $.ajax({
            type: "POST",
            url: "/availableAppointmentsForUser",
            data: { selectedDate: selectedDate },
            success: function (response) {
                const { allTimeSlots ,availableTimeSlotsForUser,selectedDate } = response;

                // Populate the dropdown with the new time slots
                // Clear the existing options
                $("#timeSlotSelect").empty();
                allTimeSlots.forEach(slot => {
                    if(availableTimeSlotsForUser.includes(slot)){
                        $("#timeSlotSelect").append(`<option value="${slot}" >${slot}</option>`)
                    }else{
                        
                        $("#timeSlotSelect").append(`<option value="${slot}" disabled>${slot}</option>`);
                    }
                });
                $("#timeSlotSelect").removeAttr('hidden');
            },

            error: function (error) {
                console.error(error);
            }
        });
    });
    // Set the current date to the dateg2 input
    const currentDate = new Date().toISOString().split('T')[0];
    $("#dateg2").val(currentDate);

    // Trigger the change event to fetch available time slots for the current date
    $("#dateg2").change();
})



